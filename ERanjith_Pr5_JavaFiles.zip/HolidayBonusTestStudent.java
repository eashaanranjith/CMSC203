import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

/**
 * JUnit test cases for HolidayBonus class.
 * Tests all major scenarios including multiple, single, and no positive sales.
 * 
 * Name: Eashaan Ranjith
 */
public class HolidayBonusTestStudent {

    private double[][] dataSet1 = { {1, 2, 3}, {4, 5}, {6, 7, 8, 9} };
    private double[][] dataSet2 = { {0, -2, 5}, {10, 0}, {3} };
    private double[][] dataSet3 = { {100}, {200}, {300} };

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void testCalculateHolidayBonus1() {
        double[] bonuses = HolidayBonus.calculateHolidayBonus(dataSet1);
        assertEquals(3000.0, bonuses[0], 0.001);
        assertEquals(4000.0, bonuses[1], 0.001);
        assertEquals(20000.0, bonuses[2], 0.001);
    }

    @Test
    public void testCalculateTotalHolidayBonus1() {
        assertEquals(27000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet1), 0.001);
    }

    @Test
    public void testCalculateHolidayBonus2() {
        double[] bonuses = HolidayBonus.calculateHolidayBonus(dataSet2);
        assertEquals(5000.0, bonuses[0], 0.001);
        assertEquals(5000.0, bonuses[1], 0.001);
        assertEquals(1000.0, bonuses[2], 0.001);
    }

    @Test
    public void testCalculateTotalHolidayBonus2() {
        assertEquals(11000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet2), 0.001);
    }

    @Test
    public void testCalculateHolidayBonus3() {
        double[] bonuses = HolidayBonus.calculateHolidayBonus(dataSet3);
        assertEquals(1000.0, bonuses[0], 0.001);
        assertEquals(2000.0, bonuses[1], 0.001);
        assertEquals(5000.0, bonuses[2], 0.001);
    }

    @Test
    public void testCalculateTotalHolidayBonus3() {
        assertEquals(8000.0, HolidayBonus.calculateTotalHolidayBonus(dataSet3), 0.001);
    }
}

/*
 * Class: CMSC203 CRN 22172
 * Instructor: Farnaz Eivazi
 * Description: Computes holiday bonuses for stores based on their sales data.
 * Due: 11/17/2025
 * Platform/compiler: Java
 * I pledge that I have completed the programming assignment independently.
 * Name: Eashaan Ranjith
 */
public class HolidayBonus {
	// Constants
	private static final double HIGH_BONUS = 5000.0;
	private static final double LOW_BONUS = 1000.0;
	private static final double OTHER_BONUS = 2000.0;

	/**
	 * Default constructor
	 */
	public HolidayBonus() {
	}

	/**
	 * Calculates the holiday bonus for each store.
	 * 
	 * @param data two dimensional ragged array of store sales
	 * @return an array of bonuses for each store
	 */
	public static double[] calculateHolidayBonus(double[][] data) {
		double[] bonuses = new double[data.length];

		// Determine max number of columns
		int maxCols = 0;
		for (int i = 0; i < data.length; i++) {
			if (data[i].length > maxCols)
				maxCols = data[i].length;
		}

		// For each column determine highest and lowest positive values
		for (int col = 0; col < maxCols; col++) {

			int highestIndex = -1;
			int lowestIndex = -1;
			double highestValue = Double.NEGATIVE_INFINITY;
			double lowestValue = Double.POSITIVE_INFINITY;
			int positiveCount = 0;

			for (int row = 0; row < data.length; row++) {
				if (col < data[row].length) {
					double value = data[row][col];
					if (value > 0) {
						positiveCount++;

						if (value > highestValue) {
							highestValue = value;
							highestIndex = row;
						}

						if (value < lowestValue) {
							lowestValue = value;
							lowestIndex = row;
						}
					}
				}
			}

			if (positiveCount == 0)
				continue;

			if (positiveCount == 1) {
				bonuses[highestIndex] += HIGH_BONUS;
				continue;
			}

			bonuses[highestIndex] += HIGH_BONUS;
			bonuses[lowestIndex] += LOW_BONUS;

			for (int row = 0; row < data.length; row++) {
				if (col < data[row].length) {
					double value = data[row][col];
					if (value > 0 && row != highestIndex && row != lowestIndex) {
						bonuses[row] += OTHER_BONUS;
					}
				}
			}
		}

		return bonuses;
	}

	/**
	 * Calculates the total holiday bonuses.
	 * 
	 * @param data two dimensional ragged array of store sales
	 * @return the total of all bonuses
	 */
	public static double calculateTotalHolidayBonus(double[][] data) {
		double total = 0;
		double[] bonusArray = calculateHolidayBonus(data);

		for (double b : bonusArray)
			total += b;

		return total;
	}
}

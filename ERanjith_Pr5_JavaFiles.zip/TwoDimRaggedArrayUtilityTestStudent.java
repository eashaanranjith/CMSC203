import static org.junit.Assert.*;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class TwoDimRaggedArrayUtilityTestStudent {
    private double[][] data1 = { {1, 2, 3}, {4, 5}, {6, 7, 8, 9} };

    @Before
    public void setUp() throws Exception { }

    @After
    public void tearDown() throws Exception { }

    @Test
    public void testGetRowTotal() {
        assertEquals(6.0, TwoDimRaggedArrayUtility.getRowTotal(data1, 0), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getRowTotal(data1, 1), 0.001);
        assertEquals(30.0, TwoDimRaggedArrayUtility.getRowTotal(data1, 2), 0.001);
    }

    @Test
    public void testGetColumnTotal() {
        assertEquals(11.0, TwoDimRaggedArrayUtility.getColumnTotal(data1, 0), 0.001);
        assertEquals(14.0, TwoDimRaggedArrayUtility.getColumnTotal(data1, 1), 0.001);
        assertEquals(11.0, TwoDimRaggedArrayUtility.getColumnTotal(data1, 2), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getColumnTotal(data1, 3), 0.001);
    }

    @Test
    public void testGetHighestInRow() {
        assertEquals(3.0, TwoDimRaggedArrayUtility.getHighestInRow(data1, 0), 0.001);
        assertEquals(5.0, TwoDimRaggedArrayUtility.getHighestInRow(data1, 1), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInRow(data1, 2), 0.001);
    }

    @Test
    public void testGetLowestInRow() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInRow(data1, 0), 0.001);
        assertEquals(4.0, TwoDimRaggedArrayUtility.getLowestInRow(data1, 1), 0.001);
        assertEquals(6.0, TwoDimRaggedArrayUtility.getLowestInRow(data1, 2), 0.001);
    }

    @Test
    public void testGetHighestInColumn() {
        assertEquals(6.0, TwoDimRaggedArrayUtility.getHighestInColumn(data1, 0), 0.001);
        assertEquals(7.0, TwoDimRaggedArrayUtility.getHighestInColumn(data1, 1), 0.001);
        assertEquals(8.0, TwoDimRaggedArrayUtility.getHighestInColumn(data1, 2), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInColumn(data1, 3), 0.001);
    }

    @Test
    public void testGetLowestInColumn() {
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInColumn(data1, 0), 0.001);
        assertEquals(2.0, TwoDimRaggedArrayUtility.getLowestInColumn(data1, 1), 0.001);
        assertEquals(3.0, TwoDimRaggedArrayUtility.getLowestInColumn(data1, 2), 0.001);
        assertEquals(9.0, TwoDimRaggedArrayUtility.getLowestInColumn(data1, 3), 0.001);
    }

    @Test
    public void testGetTotalAndAverage() {
        assertEquals(45.0, TwoDimRaggedArrayUtility.getTotal(data1), 0.001);
        assertEquals(45.0 / 9, TwoDimRaggedArrayUtility.getAverage(data1), 0.001);
    }

    @Test
    public void testGetHighestAndLowestInArray() {
        assertEquals(9.0, TwoDimRaggedArrayUtility.getHighestInArray(data1), 0.001);
        assertEquals(1.0, TwoDimRaggedArrayUtility.getLowestInArray(data1), 0.001);
    }
}

/*
 * Class: CMSC203 CRN 22172
 * Instructor: Farnaz Eivazi
 * Description: Provides utility methods for working with two-dimensional ragged arrays.
 * Due: 11/17/2025
 * Platform/compiler: Java
 * I pledge that I have completed the programming assignment independently.
 * Name: Eashaan Ranjith
 */
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public final class TwoDimRaggedArrayUtility {

	public TwoDimRaggedArrayUtility() {
	}

	private static final int MAX_ROWS = 10;
	private static final int MAX_COLS = 10;

	/**
	 * Reads from a file and returns a ragged array of doubles.
	 */
	public static double[][] readFile(File file) throws FileNotFoundException {

		String[][] temp = new String[MAX_ROWS][MAX_COLS];

		Scanner scanner = new Scanner(file);
		int row = 0;

		// Read all lines and store into temp string matrix
		while (scanner.hasNextLine() && row < MAX_ROWS) {
			String line = scanner.nextLine().trim();
			if (!line.isEmpty()) {
				String[] values = line.split(" ");
				for (int col = 0; col < values.length && col < MAX_COLS; col++) {
					temp[row][col] = values[col];
				}
				row++;
			}
		}
		scanner.close();

		if (row == 0) {
			return null;
		}

		// Create ragged array
		double[][] result = new double[row][];

		for (int r = 0; r < row; r++) {
			int colCount = 0;
			for (int c = 0; c < MAX_COLS; c++) {
				if (temp[r][c] != null)
					colCount++;
			}

			result[r] = new double[colCount];

			for (int c = 0; c < colCount; c++) {
				result[r][c] = Double.parseDouble(temp[r][c]);
			}
		}

		return result;
	}

	/**
	 * Writes the ragged array to a file.
	 */
	public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException {
		PrintWriter writer = new PrintWriter(outputFile);

		for (int r = 0; r < data.length; r++) {
			for (int c = 0; c < data[r].length; c++) {
				writer.print(data[r][c]);
				if (c < data[r].length - 1)
					writer.print(" ");
			}
			writer.println();
		}

		writer.close();
	}

	/**
	 * Returns the total of all elements.
	 */
	public static double getTotal(double[][] data) {
		double total = 0;
		for (double[] row : data) {
			for (double value : row) {
				total += value;
			}
		}
		return total;
	}

	/**
	 * Returns the average of all elements.
	 */
	public static double getAverage(double[][] data) {
		double total = 0;
		int count = 0;

		for (double[] row : data) {
			for (double value : row) {
				total += value;
				count++;
			}
		}
		return total / count;
	}

	/**
	 * Returns the total of a row.
	 */
	public static double getRowTotal(double[][] data, int row) {
		double total = 0;
		for (double value : data[row]) {
			total += value;
		}
		return total;
	}

	/**
	 * Returns the total of a column.
	 */
	public static double getColumnTotal(double[][] data, int col) {
		double total = 0;
		for (int r = 0; r < data.length; r++) {
			if (col < data[r].length) {
				total += data[r][col];
			}
		}
		return total;
	}

	/**
	 * Returns highest value in a row.
	 */
	public static double getHighestInRow(double[][] data, int row) {
		double highest = data[row][0];
		for (double v : data[row]) {
			if (v > highest)
				highest = v;
		}
		return highest;
	}

	/**
	 * Returns index of highest value in a row.
	 */
	public static int getHighestInRowIndex(double[][] data, int row) {
		int index = 0;
		double highest = data[row][0];

		for (int c = 1; c < data[row].length; c++) {
			if (data[row][c] > highest) {
				highest = data[row][c];
				index = c;
			}
		}
		return index;
	}

	/**
	 * Returns lowest value in a row.
	 */
	public static double getLowestInRow(double[][] data, int row) {
		double lowest = data[row][0];
		for (double v : data[row]) {
			if (v < lowest)
				lowest = v;
		}
		return lowest;
	}

	/**
	 * Returns index of lowest value in a row.
	 */
	public static int getLowestInRowIndex(double[][] data, int row) {
		int index = 0;
		double lowest = data[row][0];

		for (int c = 1; c < data[row].length; c++) {
			if (data[row][c] < lowest) {
				lowest = data[row][c];
				index = c;
			}
		}
		return index;
	}

	/**
	 * Returns highest value in a column.
	 */
	public static double getHighestInColumn(double[][] data, int col) {
		double highest = Double.NEGATIVE_INFINITY;

		for (int r = 0; r < data.length; r++) {
			if (col < data[r].length) {
				if (data[r][col] > highest)
					highest = data[r][col];
			}
		}
		return highest;
	}

	/**
	 * Returns index of highest value in a column.
	 */
	public static int getHighestInColumnIndex(double[][] data, int col) {
		int index = -1;
		double highest = Double.NEGATIVE_INFINITY;

		for (int r = 0; r < data.length; r++) {
			if (col < data[r].length) {
				if (data[r][col] > highest) {
					highest = data[r][col];
					index = r;
				}
			}
		}
		return index;
	}

	/**
	 * Returns lowest in a column.
	 */
	public static double getLowestInColumn(double[][] data, int col) {
		double lowest = Double.POSITIVE_INFINITY;

		for (int r = 0; r < data.length; r++) {
			if (col < data[r].length) {
				if (data[r][col] < lowest)
					lowest = data[r][col];
			}
		}
		return lowest;
	}

	/**
	 * Returns index of lowest in a column.
	 */
	public static int getLowestInColumnIndex(double[][] data, int col) {
		int index = -1;
		double lowest = Double.POSITIVE_INFINITY;

		for (int r = 0; r < data.length; r++) {
			if (col < data[r].length) {
				if (data[r][col] < lowest) {
					lowest = data[r][col];
					index = r;
				}
			}
		}
		return index;
	}

	/**
	 * Returns highest in entire array.
	 */
	public static double getHighestInArray(double[][] data) {
		double highest = Double.NEGATIVE_INFINITY;
		for (double[] row : data) {
			for (double v : row) {
				if (v > highest)
					highest = v;
			}
		}
		return highest;
	}

	/**
	 * Returns lowest in entire array.
	 */
	public static double getLowestInArray(double[][] data) {
		double lowest = Double.POSITIVE_INFINITY;
		for (double[] row : data) {
			for (double v : row) {
				if (v < lowest)
					lowest = v;
			}
		}
		return lowest;
	}
}

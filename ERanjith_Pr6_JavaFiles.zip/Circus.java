import java.util.ArrayList;
import java.util.List;

public class Circus {
    private List<Animal> animals;
    private List<Person> persons;
    private List<Building> buildings;
    private List<Ticket> tickets;

    public Circus() {
        animals = new ArrayList<>();
        persons = new ArrayList<>();
        buildings = new ArrayList<>();
        tickets = new ArrayList<>();
    }

    // Add building
    public void addBuilding(Building building) {
        buildings.add(building);
    }

    // Display building
    public void displayAllBuildings() {
        if (buildings.isEmpty()) {
            System.out.println("No buildings added yet");
        } else {
            for (Building building : buildings) {
                System.out.println(building);
            }
        }
    }

    // Add person
    public void addPerson(Person person) {
        persons.add(person);
    }

    // Display person
    public void displayAllPersons() {
        if (persons.isEmpty()) {
            System.out.println("No persons added yet");
        } else {
            for (Person person : persons) {
                System.out.println(person);
            }
        }
    }
    // Add animal
    public void addAnimal(Animal animal) {
        animals.add(animal);
    }

    // Display animal using toString() method
    public void displayAllAnimals() {
        if (animals.isEmpty()) {
            System.out.println("No animals added yet");
        } else {
            for (Animal animal : animals) {
                System.out.println(animal);
            }
        }
    }

    // Selection sort to sort animals by age
    public void sortAnimalsByAge() {
        for (int i = 0; i < animals.size() - 1; i++) {
            int min = i;
            for (int j = i + 1; j < animals.size(); j++) {
                if (animals.get(j).getAge() < animals.get(min).getAge()) {
                    min = j;
                }
            }
            Animal temp = animals.get(min);
            animals.set(min, animals.get(i));
            animals.set(i, temp);
        }
    }
    
    // Selection sort to sort animals by name
    public void sortAnimalsByName() {
        for (int i = 0; i < animals.size() - 1; i++) {
            int min = i;
            for (int j = i + 1; j < animals.size(); j++) {
                if (animals.get(j).getName().compareTo(animals.get(min).getName()) < 0) {
                    min = j;
                }
            }
            Animal temp = animals.get(min);
            animals.set(min, animals.get(i));
            animals.set(i, temp);
        }
    }
    
    // Search for an animal by name
    public boolean searchAnimalByName(String name) {
        boolean found = false;
        for (Animal animal : animals) {
            if (animal.getName().equals(name)) {
                System.out.println("Animal found: " + animal);
                found = true;
            }
        }
        if (!found) {
            System.out.println("No animal found with name: " + name);
        }
        return found;
    }
    
    // Add ticket
    public void addTicket(Ticket ticket) {
        tickets.add(ticket);
    }

    // Generate ticket
    public Ticket generateTicket(String dayOfWeek, double basePrice, int age) {
        Ticket ticket = new Ticket(dayOfWeek, basePrice, age);  // Pass dayOfWeek, basePrice, age to Ticket constructor
        addTicket(ticket);
        return ticket;
    }
    // Getters that are needed yet the instructions dont exactly ask for it
    public List<Animal> getAnimals() {
        return animals;
    }
    
    public List<Person> getPersons() {
        return persons;
    }
    
    public List<Building> getBuildings() {
        return buildings;
    }
    
    public List<Ticket> getTickets() {
        return tickets;
    }
}

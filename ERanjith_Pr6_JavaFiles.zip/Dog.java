import java.util.Objects;

public class Dog implements Animal, Cloneable {
    // Instance variables
    private String name;
    private int age;
    protected String species;
    protected String color;

    // Constructor
    public Dog(String name, int age, String species, String color) {
        this.name = name;
        this.age = age;
        this.species = species;
        this.color = color;
    }

    @Override
	//move()
    public void move() {
        System.out.println("Dog runs");
    }
	
    @Override
	//makeSound()
    public void makeSound() {
        System.out.println("Dog barks");
    }

    @Override
	//getName()
    public String getName() {
        return name;
    }
    @Override
	//getAge()
    public int getAge() {
        return age;
    }

    @Override
	//clone()
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
	//equals()
    public boolean equals(Object obj) {
        // Check for reference equality
        if (this == obj) {
            return true;
        }
        
        // Check for null or different class
        if (obj == null || getClass() != obj.getClass()) {
            return false;
        }
        
        // Compare fields for logical equality
        Dog other = (Dog) obj;
        return age == other.age && 
               Objects.equals(name, other.name) && 
               Objects.equals(species, other.species) && 
               Objects.equals(color, other.color);
    }

    @Override
	//toString() 
    public String toString() {
    	return String.format("name: " + name + "\nage: " + age + "\nspecies: " + species + "\ncolor: " + color);
    }
    
}    

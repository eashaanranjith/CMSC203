import junit.framework.TestCase;

public class CryptoManagerTestStudent extends TestCase {

	// No setUp or tearDown required, as requested

	public void testIsStringInBounds() {
		// Uppercase within bounds
		assertTrue(CryptoManager.isStringInBounds("HELLO WORLD 123!"));
		// Lowercase not allowed
		assertFalse(CryptoManager.isStringInBounds("Hello World!"));
		// Some special characters within range
		assertTrue(CryptoManager.isStringInBounds("TEST 456?!"));
		// Out of bounds (ASCII beyond '_')
		assertFalse(CryptoManager.isStringInBounds("TEST\u007F"));
	}

	public void testVigenereEncryptDecrypt() {
		String plain = "HELLO WORLD 123!";
		String key = "KEY987";
		String encrypted = CryptoManager.vigenereEncryption(plain, key);
		String decrypted = CryptoManager.vigenereDecryption(encrypted, key);
		assertEquals(plain, decrypted);

		// Test out-of-bounds message
		String invalid = "Hello World!";
		assertEquals("The selected string is not in bounds, Try again.",
				CryptoManager.vigenereEncryption(invalid, key));
	}

	public void testPlayfairEncryptDecrypt() {
		String plain = "HELLO WORLD 123!";
		String key = "SECRET";
		String encrypted = CryptoManager.playfairEncryption(plain, key);
		String decrypted = CryptoManager.playfairDecryption(encrypted, key);
		assertEquals(plain, decrypted);

		// Test out-of-bounds message
		String invalid = "Hello World!";
		assertEquals("The selected string is not in bounds, Try again.",
				CryptoManager.playfairEncryption(invalid, key));
	}

	public void testCaesarEncryptDecrypt() {
		String plain = "HELLO WORLD 123!";
		int key = 5;
		String encrypted = CryptoManager.caesarEncryption(plain, key);
		String decrypted = CryptoManager.caesarDecryption(encrypted, key);
		assertEquals(plain, decrypted);

		// Test out-of-bounds message
		String invalid = "hello world!";
		assertEquals("The selected string is not in bounds, Try again.", CryptoManager.caesarEncryption(invalid, key));
	}
}

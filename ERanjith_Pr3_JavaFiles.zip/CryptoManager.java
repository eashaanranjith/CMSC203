/*
 * Class: CMSC203 CRN 22172
 * Instructor: Farnaz Eivazi
 * Description: provides static methods to encrypt and decrypt strings using Vigenere, Playfair, and Caesar ciphers. 
 * It also checks that strings are within allowed ASCII bounds and uses an 8 by 8 Playfair matrix for character encryption.
 * Due: 10/14/2025
 * Platform/compiler: Java
 * I pledge that I have completed the programming  assignment independently. 
 * I have not copied the code from a student or any source. 
 * I have not given my code to any student.
 * Print your Name here: Eashaan Ranjith
 * */

/**
 * This is a utility class that encrypts and decrypts a phrase using three
 * different approaches. 
 * 
 * The first approach is called the Vigenere Cipher. Vigenere encryption 
 * is a method of encrypting alphabetic text based on the letters of a keyword.
 * 
 * The second approach is Playfair Cipher. It encrypts two letters (a digraph) 
 * at a time instead of just one.
 * 
 * The third approach is Caesar Cipher. It is a simple replacement cipher. 
 * 
 * @author Eashaan Ranjith
 * @version 10/14/25
 */

import java.util.ArrayList;

public class CryptoManager {

	private static final char LOWER_RANGE = ' ';
	private static final char UPPER_RANGE = '_';
	private static final int RANGE = UPPER_RANGE - LOWER_RANGE + 1;

	// 64-character matrix for Playfair cipher
	private static final String ALPHABET64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 !\"#$%&'()*+,-./:;<=>?@[\\]^_";

	/**
	 * Determines if a string is within the allowable bounds of ASCII codes.
	 *
	 * @param plainText the string to check
	 * @return true if all characters are within LOWER_RANGE and UPPER_RANGE
	 */
	public static boolean isStringInBounds(String plainText) {
		for (int i = 0; i < plainText.length(); i++) {
			char currentChar = plainText.charAt(i);
			if (currentChar < LOWER_RANGE || currentChar > UPPER_RANGE) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Encrypts a string using the Vigenere cipher.
	 *
	 * @param plainText the plaintext to encrypt (uppercase)
	 * @param key       the keyword used for encryption
	 * @return the encrypted string, or error message if out of bounds
	 */
	public static String vigenereEncryption(String plainText, String key) {
		if (!isStringInBounds(plainText)) {
			return "The selected string is not in bounds, Try again.";
		}

		String encrypted = "";
		int keyLength = key.length();

		for (int i = 0; i < plainText.length(); i++) {
			char plainChar = plainText.charAt(i);
			char keyChar = key.charAt(i % keyLength);
			int shift = keyChar - LOWER_RANGE;
			char encChar = (char) (LOWER_RANGE + (plainChar - LOWER_RANGE + shift) % RANGE);
			encrypted += encChar;
		}

		return encrypted;
	}

	/**
	 * Decrypts a string encrypted with the Vigenere cipher.
	 *
	 * @param encryptedText the encrypted string
	 * @param key           the keyword used for encryption
	 * @return the original plaintext
	 */
	public static String vigenereDecryption(String encryptedText, String key) {
		String decrypted = "";
		int keyLength = key.length();

		for (int i = 0; i < encryptedText.length(); i++) {
			char encChar = encryptedText.charAt(i);
			char keyChar = key.charAt(i % keyLength);
			int shift = keyChar - LOWER_RANGE;
			char decChar = (char) (LOWER_RANGE + (encChar - LOWER_RANGE - shift + RANGE) % RANGE);
			decrypted += decChar;
		}

		return decrypted;
	}

	/**
	 * Encrypts a string using the Playfair cipher with an 8x8 ASCII matrix.
	 *
	 * @param plainText the plaintext to encrypt (uppercase)
	 * @param key       the keyword used to build the matrix
	 * @return the encrypted string, or error message if out of bounds
	 */
	public static String playfairEncryption(String plainText, String key) {
		if (!isStringInBounds(plainText)) {
			return "The selected string is not in bounds, Try again.";
		}

		char[][] matrix = buildPlayfairMatrix(key);
		String encrypted = "";

		for (int i = 0; i < plainText.length(); i += 2) {
			char first = plainText.charAt(i);
			char second = (i + 1 < plainText.length()) ? plainText.charAt(i + 1) : ' ';
			int[] pos1 = findPosition(matrix, first);
			int[] pos2 = findPosition(matrix, second);

			if (pos1[0] == pos2[0]) {
				encrypted += matrix[pos1[0]][(pos1[1] + 1) % 8];
				encrypted += matrix[pos2[0]][(pos2[1] + 1) % 8];
			} else if (pos1[1] == pos2[1]) {
				encrypted += matrix[(pos1[0] + 1) % 8][pos1[1]];
				encrypted += matrix[(pos2[0] + 1) % 8][pos2[1]];
			} else {
				encrypted += matrix[pos1[0]][pos2[1]];
				encrypted += matrix[pos2[0]][pos1[1]];
			}
		}

		return encrypted;
	}

	/**
	 * Decrypts a string encrypted with the Playfair cipher.
	 *
	 * @param encryptedText the ciphertext to decrypt
	 * @param key           the keyword used to build the matrix
	 * @return the original plaintext
	 */
	public static String playfairDecryption(String encryptedText, String key) {
		char[][] matrix = buildPlayfairMatrix(key);
		String decrypted = "";

		for (int i = 0; i < encryptedText.length(); i += 2) {
			char first = encryptedText.charAt(i);
			char second = encryptedText.charAt(i + 1);
			int[] pos1 = findPosition(matrix, first);
			int[] pos2 = findPosition(matrix, second);

			if (pos1[0] == pos2[0]) {
				decrypted += matrix[pos1[0]][(pos1[1] + 7) % 8];
				decrypted += matrix[pos2[0]][(pos2[1] + 7) % 8];
			} else if (pos1[1] == pos2[1]) {
				decrypted += matrix[(pos1[0] + 7) % 8][pos1[1]];
				decrypted += matrix[(pos2[0] + 7) % 8][pos2[1]];
			} else {
				decrypted += matrix[pos1[0]][pos2[1]];
				decrypted += matrix[pos2[0]][pos1[1]];
			}
		}

		return decrypted;
	}

	/**
	 * Encrypts a string using the Caesar cipher.
	 *
	 * @param plainText the plaintext to encrypt (uppercase)
	 * @param key       the integer shift value
	 * @return the encrypted string, or error message if out of bounds
	 */
	public static String caesarEncryption(String plainText, int key) {
		if (!isStringInBounds(plainText)) {
			return "The selected string is not in bounds, Try again.";
		}

		String encrypted = "";

		for (int i = 0; i < plainText.length(); i++) {
			char ch = plainText.charAt(i);
			char encChar = (char) (LOWER_RANGE + (ch - LOWER_RANGE + key) % RANGE);
			encrypted += encChar;
		}

		return encrypted;
	}

	/**
	 * Decrypts a string encrypted with the Caesar cipher.
	 *
	 * @param encryptedText the ciphertext to decrypt
	 * @param key           the integer shift value used for encryption
	 * @return the original plaintext
	 */
	public static String caesarDecryption(String encryptedText, int key) {
		String decrypted = "";

		for (int i = 0; i < encryptedText.length(); i++) {
			char ch = encryptedText.charAt(i);
			char decChar = (char) (LOWER_RANGE + (ch - LOWER_RANGE - key + RANGE) % RANGE);
			decrypted += decChar;
		}

		return decrypted;
	}

	/**
	 * Builds an 8x8 Playfair matrix from the key string.
	 *
	 * @param key the keyword for the matrix
	 * @return an 8x8 character matrix
	 */
	private static char[][] buildPlayfairMatrix(String key) {
		ArrayList<Character> matrixList = new ArrayList<>();

		for (char ch : key.toCharArray()) {
			if (!matrixList.contains(ch)) {
				matrixList.add(ch);
			}
		}

		for (char ch : ALPHABET64.toCharArray()) {
			if (!matrixList.contains(ch)) {
				matrixList.add(ch);
			}
		}

		char[][] matrix = new char[8][8];
		int index = 0;
		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				matrix[r][c] = matrixList.get(index++);
			}
		}

		return matrix;
	}

	/**
	 * Finds the row and column position of a character in the Playfair matrix.
	 *
	 * @param matrix the 8x8 Playfair matrix
	 * @param ch     the character to locate
	 * @return array {row, column} of the character
	 */
	private static int[] findPosition(char[][] matrix, char ch) {
		for (int r = 0; r < 8; r++) {
			for (int c = 0; c < 8; c++) {
				if (matrix[r][c] == ch) {
					return new int[] { r, c };
				}
			}
		}
		return new int[] { 0, 0 };
	}
}
/*
 * Class: CMSC203 CRN 22172 
 * Instructor: Farnaz Eivazi
 * Description:
 * Due: (10/27/2025)
 * Platform/compiler: Java
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Print your Name here: Eashaan Ranjith
 */
public class Property {

    private String propertyName;
    private String city;
    private double rentAmount;
    private String owner;
    private Plot plot;

    /**
     * Creates a new Property using empty strings.
     * It also creates a default Plot.
     */
    public Property() {
        this.propertyName = "";
        this.city = "";
        this.owner = "";
        this.rentAmount = 0.0;
        this.plot = new Plot();
    }

    /**
     * Creates a new Property object using given values.
     * It also creates a default Plot.
     * @param propertyName property name
     * @param city city where the property is located
     * @param rentAmount rent amount
     * @param owner the owner's name
     */
    public Property(String propertyName, String city, double rentAmount, String owner) {
        this.propertyName = propertyName;
        this.city = city;
        this.rentAmount = rentAmount;
        this.owner = owner;
        this.plot = new Plot();
    }

    /**
     * Creates a new Property object using given values.
     * It also creates a Plot using given values of a plot.
     * @param propertyName property name
     * @param city city where the property is located
     * @param rentAmount rent amount
     * @param owner the owner's name
     * @param x the x coordinate of the plot
     * @param y the y coordinate of the plot
     * @param width the width coordinate of the plot
     * @param depth the depth coordinate of the plot
     */
    public Property(String propertyName, String city, double rentAmount, String owner,
                    int x, int y, int width, int depth) {
        this.propertyName = propertyName;
        this.city = city;
        this.rentAmount = rentAmount;
        this.owner = owner;
        this.plot = new Plot(x, y, width, depth);
    }

    /**
     * Creates a new copy of the given property object.
     * @param otherProperty the Property object to make a copy of
     */
    public Property(Property otherProperty) {
        this.propertyName = otherProperty.propertyName;
        this.city = otherProperty.city;
        this.rentAmount = otherProperty.rentAmount;
        this.owner = otherProperty.owner;
        this.plot = new Plot(otherProperty.plot);
    }

    /**
     * Gets the plot.
     * @return the plot
     */
    public Plot getPlot() {
        return plot;
    }

    /**
     * Gets the property name.
     * @return the property name
     */
    public String getPropertyName() {
        return propertyName;
    }

    /**
     * Gets the city.
     * @return the city
     */
    public String getCity() {
        return city;
    }

    /**
     * Gets the rent amount.
     * @return the rent amount
     */
    public double getRentAmount() {
        return rentAmount;
    }

    /**
     * Gets the owner.
     * @return the owner
     */
    public String getOwner() {
        return owner;
    }

    /**
     * Represents a Property object in the following String format:
     * propertyName,city,owner,rentAmount
     * @return the string representation of a Property object
     */
    @Override
    public String toString() {
        return propertyName + "," + city + "," + owner + "," + rentAmount;
    }
}

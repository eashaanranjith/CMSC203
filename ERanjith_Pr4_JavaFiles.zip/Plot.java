/*
 * Class: CMSC203 CRN 22172
 * Instructor: Farnaz Eivazi
 * Description: Data element class representing a rectangular plot.
 * Due: 10/27/2025
 * Platform/compiler: Java
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * Name: Eashaan Ranjith
 */

public class Plot {
	// Field Summary
	private int x;
	private int y;
	private int width;
	private int depth;

	// Constructor Summary
	/**
	 * Creates a default Plot with width and depth of 1.
	 */
	public Plot() {
		this(0, 0, 1, 1);
	}

	/**
	 * Creates a Plot using the given values.
	 * 
	 * @param x     the x coordinate of the plot
	 * @param y     the y coordinate of the plot
	 * @param width the width coordinate of the plot
	 * @param depth the depth coordinate of the plot
	 */
	public Plot(int x, int y, int width, int depth) {
		this.x = x;
		this.y = y;
		this.width = width;
		this.depth = depth;
	}

	/**
	 * Creates a new plot given another plot. This constructor must call an
	 * appropriate existing constructor.
	 * 
	 * @param otherPlot the plot to make a copy of
	 */
	public Plot(Plot otherPlot) {
		this(otherPlot == null ? 0 : otherPlot.x, otherPlot == null ? 0 : otherPlot.y,
				otherPlot == null ? 1 : otherPlot.width, otherPlot == null ? 1 : otherPlot.depth);
	}

	// Method Summary
	/**
	 * Determines if the given plot instance is overlapped by the current plot.
	 * Touching edges are not considered overlap.
	 * 
	 * @param plot the plot to test against and check if overlaps
	 * @return true if the two plots overlap, false otherwise
	 */
	public boolean overlaps(Plot plot) {
		if (plot == null)
			return false;

		int thisRight = this.x + this.width;
		int thisBottom = this.y + this.depth;
		int otherRight = plot.x + plot.width;
		int otherBottom = plot.y + plot.depth;

		// If one rectangle is completely to the left, right, above, or below the other
		if (thisRight <= plot.x || otherRight <= this.x)
			return false;
		if (thisBottom <= plot.y || otherBottom <= this.y)
			return false;

		return true;
	}

	/**
	 * Determines if the given plot is encompassed by (is contained by) this plot.
	 * Inclusive edges are considered encompassed.
	 * 
	 * @param plot the plot to test against and check if encompasses
	 * @return true if the given plot is encompassed by this plot, false otherwise
	 */
	public boolean encompasses(Plot plot) {
		if (plot == null)
			return false;

		int thisRight = this.x + this.width;
		int thisBottom = this.y + this.depth;
		int otherRight = plot.x + plot.width;
		int otherBottom = plot.y + plot.depth;

		return (this.x <= plot.x && this.y <= plot.y && thisRight >= otherRight && thisBottom >= otherBottom);
	}

	// Getters and Setters
	/**
	 * Sets the x.
	 * 
	 * @param x the new x
	 */
	public void setX(int x) {
		this.x = x;
	}

	/**
	 * Sets the y.
	 * 
	 * @param y the new y
	 */
	public void setY(int y) {
		this.y = y;
	}

	/**
	 * Sets the width.
	 * 
	 * @param width the new width
	 */
	public void setWidth(int width) {
		this.width = width;
	}

	/**
	 * Sets the depth.
	 * 
	 * @param depth the new depth
	 */
	public void setDepth(int depth) {
		this.depth = depth;
	}

	/**
	 * Gets the x.
	 * 
	 * @return the x
	 */
	public int getX() {
		return x;
	}

	/**
	 * Gets the y.
	 * 
	 * @return the y
	 */
	public int getY() {
		return y;
	}

	/**
	 * Gets the width.
	 * 
	 * @return the width
	 */
	public int getWidth() {
		return width;
	}

	/**
	 * Gets the depth.
	 * 
	 * @return the depth
	 */
	public int getDepth() {
		return depth;
	}

	/**
	 * Represents a Plot object in the following String format: x,y,width,depth
	 * 
	 * @return the string representation of a plot
	 */
	@Override
	public String toString() {
		return x + "," + y + "," + width + "," + depth;
	}
}

/*
 * Class: CMSC203 CRN 22172 
 * Instructor: Farnaz Eivazi
 * Description: Represents a company that manages up to MAX_PROPERTY properties.
 * Due: 10/27/25
 * Platform/compiler: Java
 * 
 * I pledge that I have completed the programming assignment independently.
 * I have not copied the code from a student or any source.
 * I have not given my code to any student.
 * 
 * Name: Eashaan Ranjith
 */

import java.text.DecimalFormat;

public class ManagementCompany {

	public static final int MAX_PROPERTY = 5;
	public static final int MGMT_WIDTH = 10;
	public static final int MGMT_DEPTH = 10;

	private String name;
	private String taxID;
	private double mgmFeePer;
	private Property[] properties;
	private Plot plot;
	private int numberOfProperties;

	/**
	 * Creates a ManagementCompany object using empty strings, creates a default
	 * Plot with maximum width and depth and initializes the properties array.
	 */
	public ManagementCompany() {
		name = "";
		taxID = "";
		mgmFeePer = 0.0;
		plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		properties = new Property[MAX_PROPERTY];
		numberOfProperties = 0;
	}

	/**
	 * Creates a ManagementCompany object using the given values, creates a default
	 * Plot with maximum width and depth and initializes the properties array.
	 * 
	 * @param name   management Company name
	 * @param taxID  tax Id
	 * @param mgmFee management Fee
	 */
	public ManagementCompany(String name, String taxID, double mgmFee) {
		this.name = name;
		this.taxID = taxID;
		this.mgmFeePer = mgmFee;
		this.plot = new Plot(0, 0, MGMT_WIDTH, MGMT_DEPTH);
		this.properties = new Property[MAX_PROPERTY];
		this.numberOfProperties = 0;
	}

	/**
	 * Creates a ManagementCompany object using the given values, creates a Plot
	 * using the given values, and initializes the properties array. This
	 * constructor should call an appropriate existing constructor.
	 * 
	 * @param name   management Company name
	 * @param taxID  tax Id
	 * @param mgmFee management Fee
	 * @param x      the x coordinate of the plot
	 * @param y      the y coordinate of the plot
	 * @param width  the width coordinate of the plot
	 * @param depth  the depth coordinate of the plot
	 */
	public ManagementCompany(String name, String taxID, double mgmFee, int x, int y, int width, int depth) {
		this(name, taxID, mgmFee);
		this.plot = new Plot(x, y, width, depth);
	}

	/**
	 * Creates a new ManagementCompany copy of the given ManagementCompany. This
	 * constructor should call an appropriate existing constructor.
	 * 
	 * @param otherCompany the company to make a copy of
	 */
	public ManagementCompany(ManagementCompany otherCompany) {
		this(otherCompany.name, otherCompany.taxID, otherCompany.mgmFeePer, otherCompany.plot.getX(),
				otherCompany.plot.getY(), otherCompany.plot.getWidth(), otherCompany.plot.getDepth());
		this.numberOfProperties = otherCompany.numberOfProperties;
		for (int i = 0; i < MAX_PROPERTY; i++) {
			if (otherCompany.properties[i] != null) {
				this.properties[i] = new Property(otherCompany.properties[i]);
			}
		}
	}

	public String getName() {
		return name;
	}

	public String getTaxID() {
		return taxID;
	}

	public double getMgmFeePer() {
		return mgmFeePer;
	}

	public Plot getPlot() {
		return new Plot(plot);
	}

	public Property[] getProperties() {
		return properties;
	}

	public int getPropertiesCount() {
		return numberOfProperties;
	}

	/**
	 * Adds a property object by copying from another property and adds it to the
	 * properties array.
	 * 
	 * @param property the property to add
	 * @return -1 if the array is full, -2 if the Property object is null, -3 if
	 *         management company does not encompass the property plot, -4 if
	 *         property plot overlaps ANY of properties in array, otherwise return
	 *         index where added
	 */
	public int addProperty(Property property) {
		if (isPropertiesFull())
			return -1;
		if (property == null)
			return -2;
		if (!plot.encompasses(property.getPlot()))
			return -3;

		for (int i = 0; i < numberOfProperties; i++) {
			if (properties[i] != null && properties[i].getPlot().overlaps(property.getPlot()))
				return -4;
		}

		properties[numberOfProperties] = new Property(property);
		numberOfProperties++;
		return numberOfProperties - 1;
	}

	/**
	 * Adds a new property to the properties array, this method should call an
	 * appropriate existing overloaded method.
	 */
	public int addProperty(String name, String city, double rent, String owner) {
		Property property = new Property(name, city, rent, owner);
		return addProperty(property);
	}

	/**
	 * Adds a new property to the properties array, this method should call an
	 * appropriate existing overloaded method.
	 */
	public int addProperty(String name, String city, double rent, String owner, int x, int y, int width, int depth) {
		Property property = new Property(name, city, rent, owner, x, y, width, depth);
		return addProperty(property);
	}

	/**
	 * Removes the LAST property in the properties array.
	 */
	public void removeLastProperty() {
		if (numberOfProperties > 0) {
			properties[numberOfProperties - 1] = null;
			numberOfProperties--;
		}
	}

	/**
	 * Checks if the properties array has reached the maximum capacity.
	 * 
	 * @return true if properties array is full, false otherwise
	 */
	public boolean isPropertiesFull() {
		return numberOfProperties >= MAX_PROPERTY;
	}

	/**
	 * Checks if the management company has a valid (between 0-100) fee.
	 * 
	 * @return true if valid, false otherwise
	 */
	public boolean isMangementFeeValid() {
		return mgmFeePer >= 0 && mgmFeePer <= 100;
	}

	/**
	 * Returns the total rent of the properties in the properties array.
	 * 
	 * @return total rent
	 */
	public double getTotalRent() {
		double total = 0;
		for (int i = 0; i < numberOfProperties; i++) {
			if (properties[i] != null)
				total += properties[i].getRentAmount();
		}
		return total;
	}

	/**
	 * Returns the index of the property with the maximum rent amount.
	 * 
	 * @return index of the property with highest rent
	 */
	private int getHighestRentPropertyIndex() {
		if (numberOfProperties == 0)
			return -1;

		double maxRent = properties[0].getRentAmount();
		int index = 0;

		for (int i = 1; i < numberOfProperties; i++) {
			if (properties[i] != null && properties[i].getRentAmount() > maxRent) {
				maxRent = properties[i].getRentAmount();
				index = i;
			}
		}
		return index;
	}

	/**
	 * Gets the property in the array with the maximum amount of rent.
	 * 
	 * @return the property with the highest rent
	 */
	public Property getHighestRentProperty() {
		int index = getHighestRentPropertyIndex();
		if (index == -1)
			return null;
		return new Property(properties[index]);
	}

	/**
	 * Represents the information of all the properties in the properties array.
	 * 
	 * @return formatted string of management company and properties
	 */
	@Override
	public String toString() {
		String result = "List of the properties for " + name + ", taxID: " + taxID + "\n";
		result += "______________________________________________________\n";

		for (int i = 0; i < numberOfProperties; i++) {
			if (properties[i] != null) {
				result += properties[i].toString() + "\n";
			}
		}

		result += "______________________________________________________\n\n";

		DecimalFormat df = new DecimalFormat("#0.00");
		result += " total management Fee: " + df.format(getTotalRent() * (mgmFeePer / 100.0)) + "\n";

		return result;
	}
}
